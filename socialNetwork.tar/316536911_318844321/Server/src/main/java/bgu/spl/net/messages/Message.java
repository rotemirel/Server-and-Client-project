package bgu.spl.net.messages;

public interface Message {
    public short getOpcode();
}
